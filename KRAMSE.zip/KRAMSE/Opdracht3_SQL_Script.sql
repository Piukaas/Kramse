USE [Kramse_ODS]
GO
/****** Object:  Table [dbo].[D_Calendar]    Script Date: 28/03/2023 21:46:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[D_Calendar](
	[CALDAY] [datetime] NOT NULL,
	[DAY_OF_MONTH] [int] NULL,
	[CALYEAR] [int] NULL,
	[CALMONTH_ISO] [char](2) NULL,
	[CALMONTH_NAME] [varchar](20) NULL,
	[CALMONTH_NR] [int] NULL,
	[CALMONTH_NR_OF_DAYS] [int] NULL,
	[CALMONTH_FIRST_DAY] [date] NULL,
	[CALMONTH_LAST_DAY] [date] NULL,
	[CALQUARTER] [int] NULL,
	[WEEKDAY_NR] [int] NULL,
	[WEEKDAY_NAME] [varchar](20) NULL,
	[CALWEEK_ISO] [char](2) NULL,
	[CALWEEK_ISO_LONG] [varchar](7) NULL,
	[CALWEEK_ISO_YEAR] [int] NULL,
	[CALWEEK_ISO_FIRST_DAY] [date] NULL,
	[CALWEEK_ISO_LAST_DAY] [date] NULL,
	[CALWEEK_ISO_WEEKDAY_MONTH_SPLIT] [int] NULL,
	[IS_FIRST_DAY_OF_WEEK_YN] [char](1) NULL,
	[IS_LAST_DAY_OF_WEEK_YN] [char](1) NULL,
	[IS_FIRST_DAY_OF_MONTH_YN] [char](1) NULL,
	[IS_LAST_DAY_OF_MONTH_YN] [char](1) NULL,
 CONSTRAINT [PK__D_Calend__EB730BD466C005EC] PRIMARY KEY CLUSTERED 
(
	[CALDAY] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[D_Consignor]    Script Date: 28/03/2023 21:46:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[D_Consignor](
	[RowId] [int] IDENTITY(1,1) NOT NULL,
	[ConsignorId] [int] NOT NULL,
	[Consignor] [nvarchar](255) NULL,
	[City] [nvarchar](255) NULL,
	[Country] [nvarchar](255) NULL,
	[Discount] [float] NULL,
	[StartDate] [date] NOT NULL,
	[EndDate] [date] NULL,
 CONSTRAINT [PK_D_Consignor] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[D_Container]    Script Date: 28/03/2023 21:46:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[D_Container](
	[RowId] [int] IDENTITY(1,1) NOT NULL,
	[ContainerId] [varchar](50) NOT NULL,
	[Type] [varchar](50) NULL,
	[Refrigeration] [varchar](50) NULL,
	[PowerFlag] [varchar](50) NULL,
	[Length] [varchar](50) NULL,
	[Cubes] [varchar](50) NULL,
	[EuroPricePerKm] [varchar](50) NULL,
	[StartDate] [date] NOT NULL,
	[EndDate] [date] NULL,
 CONSTRAINT [PK_D_Container_1] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[D_Item]    Script Date: 28/03/2023 21:46:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[D_Item](
	[RowId] [int] IDENTITY(1,1) NOT NULL,
	[ItemId] [int] NOT NULL,
	[Description] [nvarchar](50) NULL,
	[Category] [nvarchar](50) NULL,
	[Manufacturer] [nvarchar](50) NULL,
	[ContainerType] [nvarchar](50) NULL,
	[HazardFlag] [nvarchar](50) NULL,
	[Refrigeration] [bit] NULL,
	[StartDate] [date] NOT NULL,
	[EndDate] [date] NULL,
 CONSTRAINT [PK_D_Item] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[D_Port]    Script Date: 28/03/2023 21:46:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[D_Port](
	[RowId] [int] IDENTITY(1,1) NOT NULL,
	[PortId] [int] NOT NULL,
	[Name] [nvarchar](50) NULL,
	[Country] [nvarchar](50) NULL,
	[DistanceFromOslo] [int] NULL,
	[DistanceFromPiraeus] [int] NULL,
	[PortOrder] [nvarchar](50) NULL,
	[StartDate] [date] NOT NULL,
	[EndDate] [date] NULL,
 CONSTRAINT [PK_D_Port] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[D_Ship]    Script Date: 28/03/2023 21:46:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[D_Ship](
	[RowId] [int] IDENTITY(1,1) NOT NULL,
	[ShipId] [int] NOT NULL,
	[Name] [nvarchar](50) NULL,
	[MaxTEU] [int] NULL,
	[SpeedInKnots] [int] NULL,
	[SpeedInKm_H] [int] NULL,
	[Country] [nvarchar](50) NULL,
	[Yearcost] [money] NULL,
	[Length] [int] NULL,
	[Width] [int] NULL,
	[StartDate] [date] NOT NULL,
	[EndDate] [date] NULL,
 CONSTRAINT [PK_D_Ship] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[F_ShipmentVoyage]    Script Date: 28/03/2023 21:46:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[F_ShipmentVoyage](
	[ShipmentId] [int] NOT NULL,
	[ShipRowId] [int] NOT NULL,
	[ContainerRowId] [int] NOT NULL,
	[ConsignorRowId] [int] NOT NULL,
	[ItemRowId] [int] NOT NULL,
	[ContainerNrFirst] [numeric](18, 0) NULL,
	[ContainerNrLast] [numeric](18, 0) NULL,
	[PortStartRowId] [int] NOT NULL,
	[PortCurrentRowId] [int] NOT NULL,
	[PortNextRowId] [int] NOT NULL,
	[PortEndRowId] [int] NOT NULL,
	[LegDateDepart] [datetime] NOT NULL,
	[LegDateArrival] [datetime] NOT NULL,
	[TrajectDistance] [int] NULL,
	[LoadFactor] [numeric](38, 6) NULL,
 CONSTRAINT [PK_F_ShipmentVoyage] PRIMARY KEY CLUSTERED 
(
	[ShipmentId] ASC,
	[ShipRowId] ASC,
	[ContainerRowId] ASC,
	[ConsignorRowId] ASC,
	[ItemRowId] ASC,
	[PortStartRowId] ASC,
	[PortCurrentRowId] ASC,
	[PortNextRowId] ASC,
	[PortEndRowId] ASC,
	[LegDateDepart] ASC,
	[LegDateArrival] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[F_StayDays]    Script Date: 28/03/2023 21:46:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[F_StayDays](
	[ShipRowId] [int] NULL,
	[PortRowIdCurrent] [int] NULL,
	[PortRowIdNext] [int] NULL,
	[Depart] [datetime] NULL,
	[Arrival] [datetime] NULL,
	[StayDays] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[D_Consignor] ADD  CONSTRAINT [DF_D_Consignor_StartDate]  DEFAULT (getdate()) FOR [StartDate]
GO
ALTER TABLE [dbo].[D_Consignor] ADD  CONSTRAINT [DF_D_Consignor_EndDate]  DEFAULT (NULL) FOR [EndDate]
GO
ALTER TABLE [dbo].[D_Container] ADD  CONSTRAINT [DF_D_Container_StartDate]  DEFAULT (getdate()) FOR [StartDate]
GO
ALTER TABLE [dbo].[D_Container] ADD  CONSTRAINT [DF_D_Container_EndDate]  DEFAULT (NULL) FOR [EndDate]
GO
ALTER TABLE [dbo].[D_Item] ADD  CONSTRAINT [DF_D_Item_StartDate]  DEFAULT (getdate()) FOR [StartDate]
GO
ALTER TABLE [dbo].[D_Item] ADD  CONSTRAINT [DF_D_Item_EndDate]  DEFAULT (NULL) FOR [EndDate]
GO
ALTER TABLE [dbo].[D_Port] ADD  CONSTRAINT [DF_D_Port_StartDate]  DEFAULT (getdate()) FOR [StartDate]
GO
ALTER TABLE [dbo].[D_Port] ADD  CONSTRAINT [DF_D_Port_EndDate]  DEFAULT (NULL) FOR [EndDate]
GO
ALTER TABLE [dbo].[D_Ship] ADD  CONSTRAINT [DF_D_Ship_StartDate]  DEFAULT (getdate()) FOR [StartDate]
GO
ALTER TABLE [dbo].[D_Ship] ADD  CONSTRAINT [DF_D_Ship_EndDate]  DEFAULT (NULL) FOR [EndDate]
GO
ALTER TABLE [dbo].[F_ShipmentVoyage]  WITH CHECK ADD  CONSTRAINT [FK_F_ShipmentVoyage_D_Calendar] FOREIGN KEY([LegDateDepart])
REFERENCES [dbo].[D_Calendar] ([CALDAY])
GO
ALTER TABLE [dbo].[F_ShipmentVoyage] CHECK CONSTRAINT [FK_F_ShipmentVoyage_D_Calendar]
GO
ALTER TABLE [dbo].[F_ShipmentVoyage]  WITH CHECK ADD  CONSTRAINT [FK_F_ShipmentVoyage_D_Calendar1] FOREIGN KEY([LegDateArrival])
REFERENCES [dbo].[D_Calendar] ([CALDAY])
GO
ALTER TABLE [dbo].[F_ShipmentVoyage] CHECK CONSTRAINT [FK_F_ShipmentVoyage_D_Calendar1]
GO
ALTER TABLE [dbo].[F_ShipmentVoyage]  WITH CHECK ADD  CONSTRAINT [FK_F_ShipmentVoyage_D_Consignor] FOREIGN KEY([ConsignorRowId])
REFERENCES [dbo].[D_Consignor] ([RowId])
GO
ALTER TABLE [dbo].[F_ShipmentVoyage] CHECK CONSTRAINT [FK_F_ShipmentVoyage_D_Consignor]
GO
ALTER TABLE [dbo].[F_ShipmentVoyage]  WITH CHECK ADD  CONSTRAINT [FK_F_ShipmentVoyage_D_Container] FOREIGN KEY([ContainerRowId])
REFERENCES [dbo].[D_Container] ([RowId])
GO
ALTER TABLE [dbo].[F_ShipmentVoyage] CHECK CONSTRAINT [FK_F_ShipmentVoyage_D_Container]
GO
ALTER TABLE [dbo].[F_ShipmentVoyage]  WITH CHECK ADD  CONSTRAINT [FK_F_ShipmentVoyage_D_Item] FOREIGN KEY([ItemRowId])
REFERENCES [dbo].[D_Item] ([RowId])
GO
ALTER TABLE [dbo].[F_ShipmentVoyage] CHECK CONSTRAINT [FK_F_ShipmentVoyage_D_Item]
GO
ALTER TABLE [dbo].[F_ShipmentVoyage]  WITH CHECK ADD  CONSTRAINT [FK_F_ShipmentVoyage_D_Port] FOREIGN KEY([PortStartRowId])
REFERENCES [dbo].[D_Port] ([RowId])
GO
ALTER TABLE [dbo].[F_ShipmentVoyage] CHECK CONSTRAINT [FK_F_ShipmentVoyage_D_Port]
GO
ALTER TABLE [dbo].[F_ShipmentVoyage]  WITH CHECK ADD  CONSTRAINT [FK_F_ShipmentVoyage_D_Port1] FOREIGN KEY([PortCurrentRowId])
REFERENCES [dbo].[D_Port] ([RowId])
GO
ALTER TABLE [dbo].[F_ShipmentVoyage] CHECK CONSTRAINT [FK_F_ShipmentVoyage_D_Port1]
GO
ALTER TABLE [dbo].[F_ShipmentVoyage]  WITH CHECK ADD  CONSTRAINT [FK_F_ShipmentVoyage_D_Port2] FOREIGN KEY([PortNextRowId])
REFERENCES [dbo].[D_Port] ([RowId])
GO
ALTER TABLE [dbo].[F_ShipmentVoyage] CHECK CONSTRAINT [FK_F_ShipmentVoyage_D_Port2]
GO
ALTER TABLE [dbo].[F_ShipmentVoyage]  WITH CHECK ADD  CONSTRAINT [FK_F_ShipmentVoyage_D_Port3] FOREIGN KEY([PortEndRowId])
REFERENCES [dbo].[D_Port] ([RowId])
GO
ALTER TABLE [dbo].[F_ShipmentVoyage] CHECK CONSTRAINT [FK_F_ShipmentVoyage_D_Port3]
GO
ALTER TABLE [dbo].[F_ShipmentVoyage]  WITH CHECK ADD  CONSTRAINT [FK_F_ShipmentVoyage_D_Ship] FOREIGN KEY([ShipRowId])
REFERENCES [dbo].[D_Ship] ([RowId])
GO
ALTER TABLE [dbo].[F_ShipmentVoyage] CHECK CONSTRAINT [FK_F_ShipmentVoyage_D_Ship]
GO
ALTER TABLE [dbo].[F_StayDays]  WITH CHECK ADD  CONSTRAINT [FK_F_StayDays_D_Calendar] FOREIGN KEY([Depart])
REFERENCES [dbo].[D_Calendar] ([CALDAY])
GO
ALTER TABLE [dbo].[F_StayDays] CHECK CONSTRAINT [FK_F_StayDays_D_Calendar]
GO
ALTER TABLE [dbo].[F_StayDays]  WITH CHECK ADD  CONSTRAINT [FK_F_StayDays_D_Calendar1] FOREIGN KEY([Arrival])
REFERENCES [dbo].[D_Calendar] ([CALDAY])
GO
ALTER TABLE [dbo].[F_StayDays] CHECK CONSTRAINT [FK_F_StayDays_D_Calendar1]
GO
ALTER TABLE [dbo].[F_StayDays]  WITH CHECK ADD  CONSTRAINT [FK_F_StayDays_D_Port] FOREIGN KEY([PortRowIdCurrent])
REFERENCES [dbo].[D_Port] ([RowId])
GO
ALTER TABLE [dbo].[F_StayDays] CHECK CONSTRAINT [FK_F_StayDays_D_Port]
GO
ALTER TABLE [dbo].[F_StayDays]  WITH CHECK ADD  CONSTRAINT [FK_F_StayDays_D_Ship] FOREIGN KEY([ShipRowId])
REFERENCES [dbo].[D_Ship] ([RowId])
GO
ALTER TABLE [dbo].[F_StayDays] CHECK CONSTRAINT [FK_F_StayDays_D_Ship]
GO
